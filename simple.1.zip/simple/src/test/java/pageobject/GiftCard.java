package pageobject;

import java.io.IOException;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.How;

import utillities.JsonRead;

 

public class GiftCard extends BasePage {

 

              public GiftCard(WebDriver driver) {

                             super(driver);

                             // TODO Auto-generated constructor stub

                            

              }

              // locators And WebElements

             

              // XPath for Select Gift Cards

              @FindBy(how = How.XPATH, using = "(//*[ contains (text(), 'Gift Cards' )])[1]")

              public WebElement GiftCards;

             

              // XPath for birthday Anniversary

              @FindBy(how = How.XPATH, using = "//h3[contains(text(),'Birthday')]")

              WebElement Birthday;

             

              // XPath for giving the amount

              @FindBy(how = How.XPATH, using = "//input[@placeholder='Amount']")

              WebElement Amount;

             

              // XPath for giving Date

              @FindBy(how = How.XPATH, using = "//select[@class='Upz18 _1hLiD UJU2v'][1]")

              WebElement Month;

             

              // XPath for giving Date

              @FindBy(how = How.XPATH, using = "//select[@class='Upz18 _1hLiD UJU2v'][2]")

              WebElement Date;

             

              // XPath for select month

              @FindBy(how = How.XPATH, using = "//option[@value='4/2024']")

              WebElement MonthSelect;

             

              // XPath for select date

              @FindBy(how = How.XPATH, using = "//option[@value='24']")

              WebElement DateSelect;

             

              // XPath for Next

              @FindBy(how = How.XPATH, using = "//button[text()='Next']")

              WebElement Next;

             

              // XPath Recipient Name

              @FindBy(how = How.NAME, using = "recipient_name")

              WebElement RecipientName;

             

              // XPath Recipient Email

              @FindBy(how = How.NAME, using = "recipient_email")

              WebElement RecipientEmail;

             

              // XPath for Recipient Mobile

              @FindBy(how = How.NAME, using = "recipient_mobile_number")

              WebElement RecipientMobile;

             

              // XPath for CustomerName

              @FindBy(how = How.NAME, using = "customer_name")

              WebElement CustomerName;

             

              // XPath for CustomerEmail

              @FindBy(how = How.NAME, using = "customer_email")

              WebElement CustomerEmail;

             

              // XPath for CustomerMobileNumber

              @FindBy(how = How.NAME, using = "customer_mobile_number")

              WebElement CustomerMobileNumber;

             

              // XPath for CustomerAddress

              @FindBy(how = How.NAME, using = "customer_address")

              WebElement CustomerAddress;

             

              // XPath for PinCode

              @FindBy(how = How.NAME, using = "zip")

              WebElement PinCode;

             

              // XPath for CustomerCity

              @FindBy(how = How.XPATH, using = "//*[@id=\"ip_1554905400\"]")

              WebElement CustomerCity;

             

              // XPath for Message

              @FindBy(how = How.XPATH, using = "//*[@id=\"ip_582840596\"]")

              WebElement Message;

             

              // XPath for click

              @FindBy(how = How.XPATH, using = "//button[text()='Confirm']")

              WebElement Confirm;

             

              @FindBy(how = How.XPATH, using = "//*[@id='app-container']/div/main/section/section[4]/div[2]")

              WebElement Receipt;

             

              @FindBy(how = How.XPATH, using = "//div[@class='BCLqs']")

              WebElement ReceiptAmount;

             

              @FindBy(how = How.XPATH, using = "//div[@class='dL47V']/div")

              List<WebElement> ReceiptList;

             

              @FindBy(how = How.XPATH, using ="//div[@class='_2O3hg']/div[@class='dL47V']")

              WebElement ReceiptMessage;

             

              public String amount, recipientName, recipientEmail, recipientMobile, customerName, customerEmail, customerMobile, customerAddress, pin, message;


              JavascriptExecutor js = (JavascriptExecutor) driver;

              // Methods

 

              public void ClickGiftcards() {

                  driver.navigate().refresh();

                  GiftCards.click();

                  Birthday.click();

              }

 

              public void getcustomization() {

                  JsonRead.readJSONFile();

                  Amount.sendKeys(JsonRead.amount);

                  Month.click();

                  MonthSelect.click();

                  Date.click();

                  DateSelect.click();

              }

 

              public void fillInvaliddetails(){

                  RecipientName.sendKeys(JsonRead.recipientName);

                  RecipientEmail.sendKeys(JsonRead.recipientEmail);

                  RecipientMobile.sendKeys(JsonRead.recipientMobile);

                  CustomerName.sendKeys(JsonRead.customerName);

                  CustomerEmail.sendKeys(JsonRead.customerWrongEmail);

                  CustomerMobileNumber.sendKeys(JsonRead.customerMobile);

                  CustomerAddress.sendKeys(JsonRead.customerAddress);

                  PinCode.sendKeys(JsonRead.Pin);

                  Message.sendKeys(JsonRead.message);

                  Confirm.click();

              }

 

              public void fillValiddetails() {

                  CustomerEmail.clear();

                  CustomerEmail.sendKeys(JsonRead.customerEmail);

                  Confirm.click();

              }

 

              public void checkdetails() throws IOException {

                  amount = ReceiptAmount.getText();

                  recipientName = ReceiptList.get(0).getText();

                  recipientEmail = ReceiptList.get(1).getText();

                  recipientMobile = ReceiptList.get(2).getText();

                  customerName = ReceiptList.get(3).getText();

                  customerEmail = ReceiptList.get(4).getText();

                  customerMobile = ReceiptList.get(5).getText();

                  customerAddress = ReceiptList.get(6).getText();

                  pin = ReceiptList.get(7).getText().split(",")[0].trim();

                  message = ReceiptMessage.getText();

              }
              public void writeDetailsToJson() throws IOException {
            	    JsonRead.writeToJson(amount, recipientName, recipientEmail, recipientMobile, customerName, customerEmail,
            	        customerMobile, customerAddress, pin, message);
            	}

}
