package pageobject;


import java.util.List;

 

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.How;

 

public class DropDown extends BasePage {

 

    public DropDown(WebDriver driver) {

        super(driver);

    }

 

    @FindBy(how = How.XPATH, using = "//*[@id='topnav_wrapper']/ul/li[3]/span")

    public WebElement SelectLiving;

 

    @FindBy(how = How.XPATH, using = "//*[@id='topnav_wrapper']/ul/li[3]/div/div/ul/li[3]")

    public List<WebElement> UnderLiving;

 

    // Methods

    public void printLivingDetails() throws InterruptedException {

        System.out.println("--The details---");

        // Click on "Living" to expand

        if(SelectLiving != null) {

            SelectLiving.click();

        }

 

       
 

        // Print details of each sub-element

        for (WebElement element : UnderLiving) {

            System.out.println(element.getText());

        }

    }

}
