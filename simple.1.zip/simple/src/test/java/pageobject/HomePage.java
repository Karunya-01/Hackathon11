package pageobject;


import java.io.IOException;

import java.util.ArrayList;

import java.util.List;

 

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.How;

import utillities.Excelutils;

 

public class HomePage extends BasePage {

    Excelutils eu = new Excelutils();

 

    public HomePage(WebDriver driver) {

        super(driver);

    }

 

    @FindBy(how = How.XPATH, using = "//input[@id='search']")

    WebElement searchBox;

 

    @FindBy(how = How.XPATH, using = "//div[@class='tt-suggestion tt-selectable']/strong[contains(text(),'bookshelves')]")

    List<WebElement> select;

 

    @FindBy(how = How.XPATH, using = "//*[@id='urban-ladder-search']/form/div/span/div/div/div[1]")

    WebElement bookShelfSelect;

 

    @FindBy(how = How.XPATH, using = "//li[@data-group='price'  and @class='item']")

    WebElement priceFilter;

 

    @FindBy(how = How.XPATH, using = "//div[@class='noUi-handle noUi-handle-upper']")

    WebElement dragVisible;

 

    @FindBy(how = How.XPATH, using = "//a[@class='close-reveal-modal hide-mobile']")

    WebElement popupClose;

 

    @FindBy(how = How.XPATH, using = "//li[@data-group='category' and @class='item']")

    WebElement category;

 

    @FindBy(how = How.XPATH, using = "//input[@type='checkbox'  and @value='Kids Bookshelves']")

    WebElement categoryOption;

 

    @FindBy(how = How.XPATH, using = "//input[@value='In Stock Only']")

    WebElement checkbox;

 

    @FindBy(how = How.XPATH, using = "//div[@data-group='sorting' and @class='item']")

    WebElement sortDropDown;

 

    @FindBy(how = How.XPATH, using = "//li[@class='option' and @data-key='price_desc']")

    WebElement highToLow;

 

    @FindBy(how = How.XPATH, using = "//ul[@class='productlist small-block-grid-3']/li")

    List<WebElement> bookShelvesResult;

   

    @FindBy(how = How.XPATH, using = "//span[@itemprop='name'])")

    List<WebElement> bookShelvesNameDetail;

   

    @FindBy(how = How.XPATH, using = "//div[@class='price-number']/span")

    List<WebElement> bookShelvesPriceDetail;

 

    String productName;

    String productPrice;

    List<String> productNameList = new ArrayList<String>();

    List<String> productPriceList = new ArrayList<String>();

    Actions action = new Actions(driver);

    JavascriptExecutor js = (JavascriptExecutor) driver;

    public void clickBookShelves() {

        searchBox.sendKeys("BookShelves");

        bookShelfSelect.click();

    }

 

    public void closePopUp() {

              Wait(popupClose,60);

        try {

            hoverOverElement(popupClose);

            popupClose.click();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

 

    public void priceFilter() {

        Wait(priceFilter, 50);

        hoverOverElement(priceFilter);

        Wait(dragVisible, 50);

        action.moveToElement(dragVisible).dragAndDropBy(dragVisible, -211, 0).build().perform();

    }

 

    public void category() {

        Wait(category,50);

        hoverOverElement(category);

        categoryOption.click();

    }

 

    public void outOfStockCheckbox() {

        Wait(checkbox, 50);

        js.executeScript("arguments[0].click()", checkbox);

    }

 

    public void sortBy() {

        Wait(sortDropDown, 50);

        hoverOverElement(sortDropDown);

        Wait(highToLow, 50);

        highToLow.click();

    }

 

    public void getBookshelvesDetails() throws IOException {

             

        for (int i = 0; i < 3 && i < bookShelvesResult.size(); i++) {

            WebElement product = bookShelvesResult.get(i);

            hoverOverElement(product);

            productName = product.findElement(By.cssSelector(".product-title-sofa-mattresses > span")).getText();

            productPrice = product.findElement(By.cssSelector(".price-number > span")).getText();

            System.out.println("Product " + (i + 1) + ": " + productName);

            System.out.println("Price Of " + (i + 1) + ":" + productPrice);

        }

 

        for (int i = 0; i < bookShelvesResult.size(); i++) {

            WebElement product = bookShelvesResult.get(i);

            Wait(product,20);

            productName = product.findElement(By.cssSelector(".product-title-sofa-mattresses > span")).getText();

            productNameList.add(productName);

            productPrice = product.findElement(By.cssSelector(".price-number > span")).getText();

            productPriceList.add(productPrice);

        }

    }

   

    public void writeExcel() throws IOException {

              try {

            eu.writeExcel("BookShelves1", productNameList, 0);

            eu.writeExcel("BookShelves1", productPriceList, 1);

        } catch (IOException e) {

            e.printStackTrace();

        }

    }

}