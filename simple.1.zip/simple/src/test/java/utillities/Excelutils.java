package utillities;

import java.io.File;

import java.io.FileInputStream;

import java.io.FileOutputStream;

import java.io.IOException;

import java.util.List;

 

import org.apache.poi.ss.usermodel.Cell;

import org.apache.poi.ss.usermodel.CellStyle;

import org.apache.poi.ss.usermodel.FillPatternType;

import org.apache.poi.ss.usermodel.Font;

import org.apache.poi.ss.usermodel.IndexedColors;

import org.apache.poi.ss.usermodel.Row;

import org.apache.poi.xssf.usermodel.*;

 

public class Excelutils {

    FileInputStream fi;

    FileOutputStream fo;

    XSSFWorkbook wb;

    XSSFSheet ws;

    XSSFRow row;

    XSSFCell cell;

 

    public void writeExcel(String fileName, List<String> arr, int c) throws IOException {

    	File file = new File(System.getProperty("user.dir") + "\\testdata\\" + fileName + ".xlsx");

 

        if (file.exists()) {

            fi = new FileInputStream(file);

            wb = new XSSFWorkbook(fi);

            ws = wb.getSheetAt(0); // Get the first sheet of the existing workbook

        } else {

            wb = new XSSFWorkbook();

            ws = wb.createSheet();

            createHeader(ws);

        }

        int r = 1;

        for (String s : arr) {

            row = ws.createRow(r);

            if (c == 0) {

                row.createCell(0).setCellValue(s);

            } else if (c == 1) {

                row.createCell(1).setCellValue(s);

            }

            if (r <= 3) {

                colorRow(ws, row, IndexedColors.RED.getIndex());

            }

            r++;

        }

                             ws.autoSizeColumn(0);

                             ws.autoSizeColumn(1);

                             fo = new FileOutputStream(file);

                  wb.write(fo);

                             fo.close(); // Close the FileOutputStream

              }

 

              private void createHeader(XSSFSheet sheet) {

                             Row headerRow = sheet.createRow(0);

                             Cell productNameHeader = headerRow.createCell(0);

                             productNameHeader.setCellValue("Product Name");

                             Cell priceNameHeader = headerRow.createCell(1);

                             priceNameHeader.setCellValue("Product Price");

                             colorRow(sheet, headerRow, IndexedColors.GREEN.getIndex());

              }

 

              private void colorRow(XSSFSheet sheet, Row row, short color) {

                             CellStyle cellStyle = sheet.getWorkbook().createCellStyle();

                             cellStyle.setFillForegroundColor(color);

                            cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

                             Font font = sheet.getWorkbook().createFont();

                             font.setBold(true);

                             cellStyle.setFont(font);

                             for (Cell cell : row) {

                                           cell.setCellStyle(cellStyle);

                             }

              }

}