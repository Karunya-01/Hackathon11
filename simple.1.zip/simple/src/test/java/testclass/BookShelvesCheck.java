package testclass;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import pageobject.HomePage;
import testbase.BaseClass;

public class BookShelvesCheck extends BaseClass {
    
    HomePage hp;

    @Test(priority=1, groups = {"smoke"})
    public void verifyBookShelves() throws InterruptedException  {
        logger.info("Verifying Book Shelves"); // Log message
        hp=new HomePage(driver);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50).getSeconds(), TimeUnit.SECONDS);
        hp.clickBookShelves();
    }

    @Test(priority=2, groups = {"regression"})
    public void popupClose() {
        logger.info("Closing Pop-up"); // Log message
        hp.closePopUp();
    }

    @Test(priority=3, groups = {"smoke", "regression"})
    public void setPriceFilter()  {
        logger.info("Setting Price Filter"); // Log message
        hp.priceFilter();
    }

    @Test(priority=4, groups = {"smoke", "regression"})
    public void sortByPriceHighToLow() {
        logger.info("Sorting by Price High to Low"); // Log message
        hp.sortBy();
    }

    @Test(priority=5, groups = {"smoke", "regression"})
    public void chooseCategory() {
        logger.info("Choosing Category"); // Log message
        hp.category();
    }

    @Test(priority=6, groups = {"smoke", "regression"})
    public void outOfStockCheckbox() {
        logger.info("Checking Out of Stock Checkbox"); // Log message
        hp.outOfStockCheckbox();
    }

    @Test(priority=7, groups = {"smoke"})
    public void getBookDetails() throws InterruptedException, IOException {
        logger.info("Getting Book Details"); // Log message
        hp.getBookshelvesDetails();
    }

    @Test(priority=8, groups = {"smoke"})
    public void writeExcel() throws IOException {
        logger.info("Writing Excel"); // Log message
        hp.writeExcel();
    }
}
