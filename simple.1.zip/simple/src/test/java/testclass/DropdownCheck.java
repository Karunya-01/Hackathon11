package testclass;

import org.testng.annotations.Test;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.*;
import pageobject.*;
import testbase.BaseClass;

public class DropdownCheck extends BaseClass {
    DropDown DD;

    @Test(priority = 1)
    public void GetDetails() throws InterruptedException {
        logger.info("Getting Living Details"); // Log message
        DD = new DropDown(driver);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50).getSeconds(), TimeUnit.SECONDS);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
        DD.printLivingDetails();
    }
}
