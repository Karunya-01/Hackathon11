package testclass;

import org.testng.annotations.Test;
import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.*;
import pageobject.*;
import testbase.BaseClass;

public class GiftcardsCheck extends BaseClass {

    GiftCard GD;

    @Test(priority = 1, groups = {"smoke"})
    public void GetGiftCards() {
        logger.info("Getting Gift Cards"); // Log message
        GD = new GiftCard(driver);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50).getSeconds(), TimeUnit.SECONDS);
        GD.ClickGiftcards();
    }

    @Test(priority = 2, groups = {"smoke"})
    public void Customizing() {
        logger.info("Customizing Gift Card"); // Log message
        GD.getcustomization();
    }

    @Test(priority = 3, groups = {"regression"})
    public void invalidDetailsFilling() throws IOException {
        logger.info("Filling Invalid Details"); // Log message
        GD.fillInvaliddetails();
        captureScreen("Invalid_Details");
    }
    
    @Test(priority = 4, groups = {"regression"})
    public void captureAndDisplayErrorMessage() {
        logger.info("Capturing and Displaying Error Message"); // Log message
        // Capture & display the error message in console output
        // Assuming the error message is captured and displayed by the fillInvaliddetails() method
        captureScreen("InvalidDeails");
    }


    @Test(priority = 5, groups = {"regression"})
    public void validateDetails() {
        logger.info("Validating Gift Card Details"); // Log message
        GD.fillValiddetails();
    }


    @Test(priority = 6, groups = {"regression"})
    public void validateAllDetails() throws IOException {
        logger.info("Validating All Details in Confirm Details section"); // Log message
        GD.checkdetails();
    }
    
    @Test(priority = 7, groups = {"regression"})
    public void writeDetailsToJson() throws IOException {
        logger.info("Writing Gift Card Details to JSON"); // Log message
        GD.writeDetailsToJson();
    }
}