package testbase;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import pageobject.HomePage;

public class BaseClass {

    protected static WebDriver driver;
    public Properties p;
    public HomePage hp;
   
    public static Logger logger = LogManager.getLogger(BaseClass.class);
    @BeforeTest
    @Parameters({ "br" })
    public void setup(String br) throws IOException {
    	//logger=LogManager.getLogger(this.getClass()); // Configure Log4j
        FileReader file = new FileReader(
                "C:\\Users\\2303842\\eclipse-workspace\\HackathonProject\\src\\test\\resources\\config.properties");
        p = new Properties();
        p.load(file);
        if (br.equals("Chrome")) {
            driver = new ChromeDriver();
        } else if (br.equals("Edge")) {
            driver = new EdgeDriver();
        }
        driver.get(p.getProperty("baseurl"));
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50).getSeconds(), TimeUnit.SECONDS);
        logger.info("Browser launched and navigated to the URL");
    }

    @AfterTest
    public void teardown() {
        driver.quit();
        logger.info("Browser closed");
    }

    public String captureScreen(String filename) {
        TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
        File sourceFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
        String targetFilePath = System.getProperty("user.dir") + "\\ScreenShot\\" + filename + ".png";
        File targetFile=new File(targetFilePath);
        sourceFile.renameTo(targetFile);
        return targetFilePath;
    }
}
